Trabajo Práctico - Sistemas Operativos - 75.08
GRUPO N°2

Integrantes:  
Cavazzoli Marcelo
Fernández Caeiro Juan Manuel
Juan Manuel Lambre 	 
Stancanelli Martín
Ludueño Lucas	 	
Werner Ezequiel


1. Pasos a seguir para instalar el programa AFRA-J  
2. Insertar el pen drive booteable en la computadora de prueba y elegir la opción de correr el sistema operativo sin instalar. Esperar a que arranque.
3. Descargar el .tar.gz (para la entrega, el archivo estará dentro del comprimido, para evitar problemas de falta de conectividad).
4. Ubicarse en el directorio donde se desee instalar el programa.  
5. Copiar el fichero `AFRA-J.tar.gz` dentro de este directorio. 
6. Descomprimir ejecutando `tar -xzvf AFRA-J.tar.gz` 
7. Se podrá observar que se extrajo la carpeta AFRA-J y dentro de esta las 2 carpetas `Grupo2` y `Archivos`, el archivo `AFINSTAL.sh`, 
   el informe `Informe Tp Sistemas Operativos` y el archivo README.md.  
8. Para instalar el programa abrir una consola y situarse en la carpeta AFRA-J.  
9. Ejecutar el siguiente comando: `bash AFINISTAL.sh`  
10. Luego seguir los pasos indicados por el mismo comando para terminar de instalar el programa.
11. Realizado el paso anterior se habrán creado toda la estructura de directorios definida en ese punto como también todos los scripts 
    de ejecución dentro de la carpeta definida como BIN, los archivos maestros y tablas dentro de la carpeta definida como MAE y los archivos 
    de llamada dentro de la carpeta `Archivos` (habrá que copiarlos, todos juntos o de a uno, dentro de la carpeta de novedades, 
    para que se vea que funciona el sistema).  
  

Pasos a seguir para ejecutar el programa AFRA-J:  
1. Para ejecutar el programa se debe ejecutar el comando: `. AFINI` (inicializador) dentro del directorio definido como BIN en los pasos anteriores.  
2. El script `AFINI` dispara el proceso demonio `AFREC`. Este puede a su vez ser lanzado o detenido con los comandos `Arrancar.sh` o `Detener.sh` respectivamente.
3. Cuando AFINI pregunte si se quiere arrancar el demonio, presionar “s” para que se empiece a ejecutar AFREC en segundo plano. Este demonio se encargará de ejecutar AFUMB en sus continuas iteraciones.
4. Una vez hecho esto, se podrá ejecutar el comando AFLIST con  sus respectivas opciones para realizar, siguiendo las opciones que ofrece en sus menúes, las consultas deseadas.
5. Si se quiere detener AFREC, se deberá utilizar el comando complementario Detener.sh


