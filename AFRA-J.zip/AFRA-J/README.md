# Trabajo Práctico - Sistemas Operativos - 75.08
## GRUPO N°2
### Integrantes:  
Ludueño Lucas  
Juan Manuel Lambre  
...

Pasos a seguir para instalar el programa AFRA-J  
1.  Insertar el dispositivo de almacenamiento con el contenido del tp (pen drive, cd, etc).  
3.  Ubicarse en el directorio donde de desee intalar el programa.  
4.  Copiar el fichero `AFRA-J.zip` dentro de este directorio.  
5.  Extraer el fichero `AFRA-J.zip`.  
6.  Se podrá observar que se extrajo la carpeta AFRA-J y dentro de esta las 2 carpetas `Grupo2` y `Archivos` y el archivo `AFINSTAL.sh`.  
7.  Para instalar el programa abrir una consola y situarse en la carpeta AFRA-J.  
8.  Ejecutar el siguiente comando: `chmod +x AFINISTAL`  
9.  Luego seguir los pasos indicados para terminar de instalar el programa.  
10. Realizado el paso 9 se habrán creado toda la estructura de directorios definida en ese punto como también todos los scripts de ejecución dentro de la carpeta definida como BIN, los archivos maestros y tablas dentro de la carpeta definida como MAE y los archivos de llamada dentro de la carpeta `Archivos`.  
  
Pasos a seguir para ejecutar el programa AFRA-J:  
1. Para ejecutar el programa se debe ejecutar el comando: `. AFINI` (inicializador) dentro del directorio definido como BIN en el paso 9.  
2. ...  

